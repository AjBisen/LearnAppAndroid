package com.dbvertex.quizappnew.Presentation.NestedSubcategories

data class NestedCategoryDTO(
    val category_name:String,
    val title:String,
    val image:String
)

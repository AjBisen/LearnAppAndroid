package com.dbvertex.quiz_app.Dashboard

data class courses_data(
    val course_img:String,
    val course_name:String,
    val inst_name:String,
    val course_price:String,
    val course_rating:String
)

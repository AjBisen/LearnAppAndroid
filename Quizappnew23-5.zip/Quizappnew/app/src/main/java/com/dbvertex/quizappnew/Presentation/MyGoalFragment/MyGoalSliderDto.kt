package com.dbvertex.quizappnew.Presentation.MyGoalFragment

data class MyGoalSliderDto(

    val image:String,
    val title:String
)

package com.dbvertex.quiz_app.Intro

data class goal_item_data(
    val icon:String,
    val nam:String
)

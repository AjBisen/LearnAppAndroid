package com.dbvertex.quizappnew.Presentation.Allgoals

data class AllGoalsDTO(
    val category_name:String,
    val title:String,
    val image:String
)

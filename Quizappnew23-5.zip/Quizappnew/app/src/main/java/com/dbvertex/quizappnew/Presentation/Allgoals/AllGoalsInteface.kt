package com.dbvertex.quizappnew.Presentation.Allgoals

interface AllGoalsInteface {
    fun onClickSingleAllGoal(allGoalsDTO: AllGoalsDTO)
}
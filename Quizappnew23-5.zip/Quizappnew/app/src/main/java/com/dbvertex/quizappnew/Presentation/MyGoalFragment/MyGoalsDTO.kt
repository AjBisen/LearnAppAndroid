package com.dbvertex.quizappnew.Presentation.MyGoalFragment

data class MyGoalsDTO(
    val bg_image:String,
    val like_status:Boolean,
    val icon_img:String,
    val title:String
)

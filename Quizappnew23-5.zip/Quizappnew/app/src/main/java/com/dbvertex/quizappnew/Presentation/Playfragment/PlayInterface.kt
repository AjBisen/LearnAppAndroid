package com.dbvertex.quizappnew.Presentation.Playfragment

interface PlayInterface {

    fun onPlayItemclick(playDTO: PlayDTO)
}
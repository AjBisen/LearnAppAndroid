package com.dbvertex.quizappnew.Presentation.MyGoalFragment

interface MygoalSliderInterface {
    fun onClickSingleMyGoalSlider(myGoalSliderDto: MyGoalSliderDto)
}
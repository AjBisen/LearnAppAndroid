package com.dbvertex.quizappnew.Presentation.AllGoalsSubcategories

data class AllGoalsCategoryDTO(
    val category_name:String,
    val title:String,
    val image:String
)

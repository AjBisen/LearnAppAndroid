package com.dbvertex.quizappnew.Presentation.NestedSubcategories

interface NestedSubcategoryInteface {
    fun onClickSingleAllGoal(allGoalsDTO: NestedCategoryDTO)
}
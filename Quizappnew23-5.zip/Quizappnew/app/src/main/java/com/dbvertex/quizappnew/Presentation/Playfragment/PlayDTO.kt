package com.dbvertex.quizappnew.Presentation.Playfragment

data class PlayDTO(

    val image:String,
    val title:String
)

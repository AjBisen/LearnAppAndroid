package com.dbvertex.quizappnew.Presentation.MyGoalFragment

interface MyGoalsInteface {
    fun onClickSingleAllGoal(allGoalsDTO: MyGoalsDTO)
}
package com.dbvertex.quizappnew.Presentation.AllGoalsSubcategories

interface AllGoalsSubcategoryInteface {
    fun onClickSingleAllGoal(allGoalsDTO: AllGoalsCategoryDTO)
}